# Puppeteer-Lighthouse
This  code will provide the client side metrics for any web page using puppeteer and lighthouse. 
